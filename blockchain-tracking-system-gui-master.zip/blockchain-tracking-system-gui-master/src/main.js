import { createApp } from 'vue'

import App from './App.vue'

import axios from "axios"

import router from "./router"

import store from "./store/index"

import PusherPlugin from "./plugins/pusher"

// Bootstrap
import "../public/css/custom-css/main.css"
import $ from "jquery"
// import "../node_modules/bootstrap/dist/css/bootstrap.css"
// import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/jquery/dist/jquery.js"
import "../node_modules/bootstrap/dist/js/bootstrap.min.js"

import Toaster from "@meforma/vue-toaster"
import VueSweetalert2 from "vue-sweetalert2"
import "sweetalert2/dist/sweetalert2.all"

axios.defaults.baseURL = "http://127.0.0.1:5000"
// axios.defaults.headers.post["Content-Type"] = "application/json"

var onResize = function(){
    // $("body").css("padding-top", $(".navbar").height())
    // $(".left-view").css("padding-top", $(".nav").height())
}

$(window).resize(onResize)

$(function(){
    onResize()
})

createApp(App)
.use(router)
.use(store)
.use(Toaster)
.use(VueSweetalert2)
.use(PusherPlugin, { api_key: "0139f6a50e684ba36682", cluster: "mt1"})
.mount('#app')
