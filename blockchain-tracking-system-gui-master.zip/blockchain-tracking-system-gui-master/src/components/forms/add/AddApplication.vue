<template>
    <!-- <LoadingScreen /> -->

    <div class="row">
        <div class="modal fade" id="add-application">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <h3 class="text-dark">Add application</h3>
                        </div>

                        <button type="button" className="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form id="add-application-form">
                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Product name:</label>
                                <input v-model="product_name" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="Product name"><br>
                            </div>

                            <!-- <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Currency:</label>
                                <input v-model="currency" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="Currency"><br>
                            </div> -->

                            <!-- <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Currency:</label>
                                <select v-model="currency" class="form-control shadow-none w-100 m-2" required placeholder="Currency">
                                    <option v-for="currency in allCurrencies" :key="currency['_id']['$oid']" :value="currency['_id']['$oid']">{{ currency.currency_name }}</option>
                                </select>
                            </div> -->

                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Price (ZWL):</label>
                                <input v-model="price" class="form-control shadow-none w-100 m-2" type="number" required placeholder="Price"><br>
                            </div>

                            <div class="row form-group">
                                <button @click.prevent="onAddApplication" class="btn btn-dark w-100 m-2 font-weight-bold">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    import $ from "jquery"
    // import LoadingScreen from "../layout/LoadingScreen"

    export default{
        name: "AddApplication",

        components: {
            // LoadingScreen
        },

        data(){
            return{
                application: {
                    product_name: "",
                    // currency: "",
                    price: "",
                }
            }
        },

        methods: {
            ...mapActions(["addApplication"]),

            async onAddApplication(){
                $(".loader").addClass("spinner-border")
                $("#add-application").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                let application = {
                    "product_name": this.product_name,
                    // "currency": this.currency,
                    "price": this.price,
                    "created_by": this.getActiveUser["first_name"] + " " + this.getActiveUser["last_name"],
                }

                await this.addApplication(application).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#add-application").modal("hide")
                        $("#add-application-form").trigger("reset")
                    }

                    else if(response.message == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        $("#add-application").modal("show")
                    }

                    $(".loader").removeClass("spinner-border")
                    // $("#loading-screen").modal("hide")
                })
            }
        },

        computed: mapGetters(["getActiveUser"])
    }
</script>

<style>
</style>