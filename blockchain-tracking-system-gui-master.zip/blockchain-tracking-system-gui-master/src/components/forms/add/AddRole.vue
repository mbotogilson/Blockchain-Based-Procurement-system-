<template>
    <!-- <LoadingScreen /> -->

    <div class="row">
        <div class="modal fade" id="add-role">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <h3 class="text-dark">Add role</h3>
                        </div>

                        <button type="button" className="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form id="add-role-form">
                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Role name:</label>
                                <input v-model="role_name" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="Role name"><br>
                            </div>

                            <div class="row form-group">
                                <button @click.prevent="onAddRole" class="btn btn-dark w-100 m-2 font-weight-bold">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    import $ from "jquery"
    // import LoadingScreen from "../layout/LoadingScreen"

    export default{
        name: "AddRole",

        components: {
            // LoadingScreen
        },

        data(){
            return{
                role: {
                    role_name: "",
                }
            }
        },

        methods: {
            ...mapActions(["addRole"]),

            async onAddRole(){
                $(".loader").addClass("spinner-border")
                $("#add-role").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                let role = {
                    "role_name": this.role_name,
                }

                await this.addRole(role).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#add-role").modal("hide")
                        $("#add-role-form").trigger("reset")
                    }

                    else if(response.message == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        $("#add-role").modal("show")
                    }

                    // $("#signup-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                    $(".loader").removeClass("spinner-border")
                })
            }
        },

        computed: mapGetters(["allRoles"])
    }
</script>

<style>
</style>