<template>
    <!-- <LoadingScreen /> -->

    <div class="row">
        <div class="modal fade" id="add-currency">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <h3 class="text-dark">Add currency</h3>
                        </div>

                        <button type="button" className="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form id="add-currency-form">
                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Currency name:</label>
                                <input v-model="currency_name" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="Currency name"><br>
                            </div>

                            <div class="row form-group">
                                <button @click.prevent="onAddCurrency" class="btn btn-dark w-100 m-2 font-weight-bold">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    import $ from "jquery"
    // import LoadingScreen from "../layout/LoadingScreen"

    export default{
        name: "AddCurrency",

        components: {
            // LoadingScreen
        },

        data(){
            return{
                currency: {
                    currency_name: "",
                }
            }
        },

        methods: {
            ...mapActions(["addCurrency"]),

            async onAddCurrency(){
                // $("#signup-spinner").addClass("spinner-grow")
                $("#add-currency").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                let currency = {
                    "currency_name": this.currency_name,
                }

                await this.addCurrency(currency).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#add-currency").modal("hide")
                        $("#add-currency-form").trigger("reset")
                    }

                    else if(response.message == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        $("#add-currency").modal("show")
                    }

                    // $("#signup-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                })
            }
        },

        computed: mapGetters(["allCurrencies"])
    }
</script>

<style>
</style>