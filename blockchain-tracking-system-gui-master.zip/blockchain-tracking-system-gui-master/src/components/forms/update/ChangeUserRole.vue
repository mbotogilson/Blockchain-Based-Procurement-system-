<template>
    <!-- <LoadingScreen /> -->

    <div class="modal fade" id="change-user-role">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <h3>Change user role</h3>
                    </div>

                    <!-- <span id="update-application-spinner" class="text-dark"></span> -->

                    <button class="close" type="button" data-dismiss="modal" arial-label="Close"><span arial-hidden="true">&times;</span></button>

                </div>

                <div class="modal-body">
                    <form id="change-user-role-form">
                        <div>
                            <label class="m-2 text-dark font-weight-bold">First name:</label>
                            <input id="first-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="First name" readonly><br>
                        </div>

                        <div>
                            <label class="m-2 text-dark font-weight-bold">Last name:</label>
                            <input id="last-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="Last name" readonly><br>
                        </div>

                        <div>
                            <label class="m-2 text-dark font-weight-bold">Role:</label>
                            <select id="role" class="form-control shadow-none w-100 m-1">
                                <option class="form-control" v-for="role in allRoles" :key="role['_id']['$oid']" :value="role['_id']['$oid']">{{ role.role_name }}</option>
                            </select>
                        </div>
                        
                        <button @click.prevent="onChangeUserRole" class="btn btn-dark w-100 m-1 font-weight-bold">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    
    import $ from "jquery"

    // import LoadingScreen from "../../layout/LoadingScreen"

    export default{
        name: "ChangeUserRole",

        components: {
            // LoadingScreen,
        },

        methods: {
            ...mapActions(["changeUserRole"]),

            async onChangeUserRole(){
                let user = {
                    "id": $("#change-user-role-form").attr("user-id"),
                    "role": $("#role").val(),
                }
                
                $(".loader").addClass("spinner-border")
                $("#change-user-role").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                await this.changeUserRole(user).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#change-user-role").modal("hide")
                        $("#change-user-role-form").trigger("reset")
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        $("#change-user-role").modal("show")
                    }

                    // $("#update-loan-product-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                    $(".loader").removeClass("spinner-border")
                })
            }
        },

        computed: mapGetters(["allRoles"]),
    }
</script>

<style>
    #update-loan-product-spinner{
        /* display: none; */
    }
</style>