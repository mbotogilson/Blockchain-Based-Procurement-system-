<template>
    <!-- <LoadingScreen /> -->

    <div class="modal fade" id="update-currency">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <h3>Update currency</h3>
                    </div>

                    <!-- <span id="update-application-spinner" class="text-dark"></span> -->

                    <button class="close" type="button" data-dismiss="modal" arial-label="Close"><span arial-hidden="true">&times;</span></button>

                </div>

                <div class="modal-body">
                    <form id="update-currency-form">
                        <div>
                            <label class="m-2 text-dark font-weight-bold">Currency name:</label>
                            <input id="currency-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="Currency name" required><br>
                        </div>
                        
                        <button @click.prevent="onUpdateCurrency" class="btn btn-dark w-100 m-1 font-weight-bold">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    
    import $ from "jquery"

    // import LoadingScreen from "../../layout/LoadingScreen"

    export default{
        name: "UpdateCurrency",

        components: {
            // LoadingScreen,
        },

        methods: {
            ...mapActions(["updateCurrency"]),

            async onUpdateCurrency(){
                let currency = {
                    "id": $("#update-currency-form").attr("currency-id"),
                    "currency_name": $("#currency-name").val(),
                }
                
                // $("#update-loan-product-spinner").addClass("spinner-grow")
                $("#update-currency").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                await this.updateCurrency(currency).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#update-currency").modal("hide")
                        $("#update-currency-form").trigger("reset")
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        $("#update-currency").modal("show")
                    }

                    // $("#update-loan-product-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                })
            }
        },

        computed: mapGetters([""]),
    }
</script>

<style>
    #update-loan-product-spinner{
        /* display: none; */
    }
</style>