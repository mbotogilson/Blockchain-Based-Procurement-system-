<template>
    <!-- <LoadingScreen /> -->

    <div class="modal fade" id="update-role">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <h3>Update role</h3>
                    </div>

                    <!-- <span id="update-application-spinner" class="text-dark"></span> -->

                    <button class="close" type="button" data-dismiss="modal" arial-label="Close"><span arial-hidden="true">&times;</span></button>

                </div>

                <div class="modal-body">
                    <form id="update-role-form">
                        <div>
                            <label class="m-2 text-dark font-weight-bold">Role name:</label>
                            <input id="role-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="Role name" required><br>
                        </div>
                        
                        <button @click.prevent="onUpdateRole" class="btn btn-dark w-100 m-1 font-weight-bold">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    
    import $ from "jquery"

    // import LoadingScreen from "../../layout/LoadingScreen"

    export default{
        name: "UpdateRole",

        components: {
            // LoadingScreen,
        },

        methods: {
            ...mapActions(["updateRole"]),

            async onUpdateRole(){
                let role = {
                    "id": $("#update-role-form").attr("role-id"),
                    "role_name": $("#role-name").val(),
                }
                
                // $("#update-loan-product-spinner").addClass("spinner-grow")
                $(".loader").addClass("spinner-border")
                $("#update-role").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                await this.updateRole(role).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#update-role").modal("hide")
                        $("#update-role-form").trigger("reset")
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        $("#update-role").modal("show")
                    }

                    // $("#update-loan-product-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                    $(".loader").removeClass("spinner-border")
                })
            }
        },

        computed: mapGetters([""]),
    }
</script>

<style>
    #update-loan-product-spinner{
        /* display: none; */
    }
</style>