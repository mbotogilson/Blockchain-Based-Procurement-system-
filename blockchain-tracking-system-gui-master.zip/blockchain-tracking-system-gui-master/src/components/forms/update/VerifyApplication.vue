<template>
    <!-- <LoadingScreen /> -->

    <div class="modal fade" id="verify-application">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <h3>Verify application</h3>
                    </div>

                    <!-- <span id="update-application-spinner" class="text-dark"></span> -->

                    <button class="close" type="button" data-dismiss="modal" arial-label="Close"><span arial-hidden="true">&times;</span></button>

                </div>

                <div class="modal-body">
                    <form id="verify-application-form">
                        <div class="row">
                            <div class="col-6">
                                <div>
                                    <label class="m-2 text-dark font-weight-bold">Product name:</label>
                                    <input id="verify-product-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="Product name" readonly><br>
                                </div>

                                <!-- <div>
                                    <label class="m-2 text-dark font-weight-bold">Currency:</label>
                                    <input id="verify-currency" class="form-control shadow-none w-100 m-1" type="text" placeholder="Currency" readonly><br>
                                </div> -->

                                <div>
                                    <label class="m-2 text-dark font-weight-bold">Price (ZWL):</label>
                                    <input id="verify-price" class="form-control shadow-none w-100 m-1" type="text" placeholder="Price" readonly><br>
                                </div>

                                <div>
                                    <label class="m-2 text-dark font-weight-bold">Application status:</label>
                                    <select id="application-status" class="form-control shadow-none w-100 m-1">
                                        <option class="form-control" value="PENDING">Pending</option>
                                        <option class="form-control" value="ACCEPTED">Accept</option>
                                        <option class="form-control" value="REJECTED">Reject</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col">
                                <div>
                                    <label class="m-2 text-dark font-weight-bold">Notes:</label>
                                    <textarea id="notes" class="form-control shadow-none w-100 m-1" cols="30" rows="10"></textarea>
                                </div>
                            </div>
                        </div>

                        <button @click.prevent="onVerifyApplication" class="btn btn-dark w-100 m-1 font-weight-bold">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    
    import $ from "jquery"

    // import LoadingScreen from "../../layout/LoadingScreen"

    export default{
        name: "VerifyApplication",

        components: {
            // LoadingScreen,
        },

        methods: {
            ...mapActions(["verifyApplication"]),

            async onVerifyApplication(){
                let application = {
                    "id": $("#verify-application-form").attr("application-id"),
                    "application_status": $("#application-status").val(),
                    "verified_by": this.getActiveUser["first_name"] + " " + this.getActiveUser["last_name"] ,
                    "notes": $("#notes").val(),
                }
                
                // $("#update-loan-product-spinner").addClass("spinner-grow")
                $(".loader").addClass("spinner-border")
                $("#verify-application").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                await this.verifyApplication(application).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#verify-application").modal("hide")
                        $("#verify-application-form").trigger("reset")
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        $("#verify-application").modal("show")
                    }

                    // $("#update-loan-product-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                    $(".loader").removeClass("spinner-border")
                })
            }
        },

        computed: mapGetters(["allCurrencies", "getActiveUser"]),
    }
</script>

<style scoped>
    .modal-fullscreen{
        width: 100%;
    }
</style>