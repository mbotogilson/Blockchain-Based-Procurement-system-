<template>
    <!-- <LoadingScreen /> -->

    <div class="modal fade" id="update-application">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="modal-title">
                        <h3>Update application</h3>
                    </div>

                    <!-- <span id="update-application-spinner" class="text-dark"></span> -->

                    <button class="close" type="button" data-dismiss="modal" arial-label="Close"><span arial-hidden="true">&times;</span></button>

                </div>

                <div class="modal-body">
                    <form id="update-application-form">
                        <div>
                            <label class="m-2 text-dark font-weight-bold">Product name:</label>
                            <input id="product-name" class="form-control shadow-none w-100 m-1" type="text" placeholder="Product name" required><br>
                        </div>

                        <!-- <div>
                            <label class="m-2 text-dark font-weight-bold">Currency:</label>
                            <select id="currency" class="form-control shadow-none w-100 m-1">
                                <option class="form-control" v-for="currency in allCurrencies" :key="currency['_id']['$oid']" :value="currency['_id']['$oid']">{{ currency.currency_name }}</option>
                            </select>
                        </div> -->

                        <div>
                            <label class="m-2 text-dark font-weight-bold">Price (ZWL):</label>
                            <input id="price" class="form-control shadow-none w-100 m-1" type="text" placeholder="Price" required><br>
                        </div>
                        
                        <button @click.prevent="onUpdateApplication" class="btn btn-dark w-100 m-1 font-weight-bold">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"
    
    import $ from "jquery"

    // import LoadingScreen from "../../layout/LoadingScreen"

    export default{
        name: "UpdateApplication",

        components: {
            // LoadingScreen,
        },

        methods: {
            ...mapActions(["updateApplication"]),

            async onUpdateApplication(){
                let application = {
                    "id": $("#update-application-form").attr("application-id"),
                    "product_name": $("#product-name").val(),
                    // "currency": $("#currency").val(),
                    "price": $("#price").val(),
                    "updated_by": this.getActiveUser["first_name"] + " " + this.getActiveUser["last_name"],
                }
                
                $(".loader").addClass("spinner-border")
                $("#update-application").modal("hide")
                // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                await this.updateApplication(application).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        // Modal
                        $("#update-application").modal("hide")
                        $("#update-application-form").trigger("reset")
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        $("#update-application").modal("show")
                    }

                    // $("#update-loan-product-spinner").removeClass("spinner-grow")
                    // $("#loading-screen").modal("hide")
                    $(".loader").removeClass("spinner-border")
                })
            }
        },

        computed: mapGetters(["allCurrencies", "getActiveUser"]),
    }
</script>

<style>
    #update-loan-product-spinner{
        /* display: none; */
    }
</style>