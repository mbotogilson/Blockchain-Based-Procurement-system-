<template>
    <ChangeUserRole />

    <div id="users">
        <div class="heading text-dark">
            <h3 class="table-caption my-auto">Users</h3>

            <div class="tools">
                <!-- <div class="fa fa-plus fa-2x center" title="add new"></div>
                <div class="fa fa-upload fa-2x center" title="upload to block chain"></div> -->

                <!-- <button class="add-new-btn btn btn-secondary" title="click to add new" disabled>add</button> -->
                <!-- <button class="upload-btn btn btn-secondary" title="click to upload to block chain" disabled>upload</button> -->
            </div>
        </div>
        <hr>

        <table class="users-table table table-striped">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <!-- <th>Record status</th> -->
                    <th v-if="getActiveUser['role']['role_name'] == 'admin'">Action</th>
                </tr>
            </thead>

            <tbody>
                <tr v-for="user in allUsers" :key="user['_id']['$oid']">
                    <td>{{ user.first_name }}</td>
                    <td>{{ user.last_name }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.role.role_name }}</td>
                    <!-- <td>{{ user.record_status }}</td> -->
                    <td v-if="getActiveUser['role']['role_name'] == 'admin'" class="d-flex">
                        <button class="btn btn-success" @click.prevent="showChangeUserRole(user)" :disabled="changeRoleBtnDisabled">change role</button>
                        <button class="btn btn-danger mx-1" @click.prevent="onDeleteUser(user['_id']['$oid'])" :disabled="deleteBtnDisabled">delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"

    import $ from "jquery"

    import ChangeUserRole from "../../forms/update/ChangeUserRole"

    export default{
        name: "Users",

        components: {
            ChangeUserRole,
        },

        data(){
            return{
                changeRoleBtnDisabled: true,
                deleteBtnDisabled: true, 
            }
        },

        methods: {
            ...mapActions(["fetchAllUsers", "fetchAllRoles", "deleteUser"]),

            showChangeUserRole(user){
                $("#change-user-role-form").attr("user-id", user["_id"]["$oid"])
                $("#first-name").val(user["first_name"])
                $("#last-name").val(user["last_name"])
                $("#role").val(user["role"]["_id"]["$oid"])
                $("#change-user-role").modal({show: true, backdrop: "static", keyboard: false})
            },

            onDeleteUser(user_id){
                // this.deleteApplication(application_id)

                this.$swal({
                    title: "Delete User?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes"
                }).then((response) => {
                    if(response.value == true){
                        // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})
                        $(".loader").addClass("spinner-border")
                        this.deleteUser(user_id).then((response) => {
                            if(response.status == "success"){
                                this.$toast.show(`${response.message}`,
                                    {
                                        type: "success", 
                                        position: "top",
                                        duration: 4000,
                                    }
                                )
                            }

                            else if(response.status == "error"){
                                this.$toast.show(`There was a problem here`,
                                    {
                                        type: "error", 
                                        position: "top",
                                        duration: 4000,
                                    }
                                )
                            }
                            // $("#global-spinner").removeClass("spinner-grow")
                            // $("#loading-screen").modal("hide")
                            $(".loader").removeClass("spinner-border")
                        })
                    }
                })
            }
        },

        created(){
            this.fetchAllUsers()
            this.fetchAllRoles()

            if(this.getActiveUser["role"]["role_name"] === "admin"){
                this.changeRoleBtnDisabled = false
                this.deleteBtnDisabled = false
            }

            else{
                this.changeRoleBtnDisabled = true
                this.deleteBtnDisabled = true
            }
        },

        computed: mapGetters(["allUsers", "getActiveUser"]),

        mounted(){
            var channel = this.$pusher.subscribe('my-channels')
            channel.bind("my-event", obj => {
                // alert(obj.message)
                if(this.getActiveUser.first_name + " " + this.getActiveUser.last_name !== obj.data.full_name){
                    this.$toast.show(obj.data.message,
                        {
                            type: "info", 
                            position: "top",
                            duration: 8000,
                        }
                    )
                }
            })
        },
    }
</script>

<style scoped>
    /* APPLICATIONS TABLE */
    #users{
        margin: 20px;
        /* border: solid 1px black; */
        min-height: 80vh;
        max-height: 80vh;
        overflow-y: scroll;
        box-shadow: 0 1px 1px rgba(0,0,0,0.12), 
                    0 2px 2px rgba(0,0,0,0.12), 
                    0 4px 4px rgba(0,0,0,0.12), 
                    0 8px 8px rgba(0,0,0,0.12),
                    0 16px 16px rgba(0,0,0,0.12);
    }

    .heading{
        display: flex;
        margin: 10px 0;
    }

    hr{
        background: #1f1f1f;
    }

    .table-caption{
        margin: auto 10px auto 10px
    }

    .tools{
        margin-left: auto;
        padding: 10px 0;
        display: flex;
    }

    .add-new-btn,
    .upload-btn{
        margin: auto 10px auto 10px;
        padding: 10px;
        
        /* width: 100%; */
        border: none;
        /* align-items: center; */
        outline: none;
    }

    table{
    }

    table, th, td{
    }
</style>