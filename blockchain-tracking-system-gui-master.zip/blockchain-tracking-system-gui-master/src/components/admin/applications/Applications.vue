<template>
    <AddApplication />
    <UpdateApplication />
    <VerifyApplication />

    <div id="applications">
        <div class="heading text-dark">
            <h3 class="table-caption my-auto">Applications</h3>

            <div class="tools">
                <!-- <div class="fa fa-plus fa-2x center" title="add new"></div>
                <div class="fa fa-upload fa-2x center" title="upload to block chain"></div> -->

                <input v-on:input="searchApplications($event.target.value)" class="search-input form-control border border-secondary shadow-none" type="text" placeholder="Type here to search...">
                <button class="add-new-btn btn btn-secondary" title="click to add new" @click.prevent="showAddApplication" v-show="addBtnDisabled">add</button>
                <button class="upload-btn btn btn-secondary" title="click to upload to block chain" v-show="uploadBtnDisabled" @click.prevent="onUploadApplications">upload</button>
            </div>
        </div>
        <hr>

        <div class="table-container">
            <table class="applications-table table table-striped display">
                <thead class="bg-secondary text-white">
                    <tr>
                        <th>Application ID</th>
                        <th>Product name</th>
                        <th>Price (ZWL)</th>
                        <th>Created by</th>
                        <th>Updated by</th>
                        <th>Verified by</th>
                        <th>Application status</th>
                        <th>Notes</th>
                        <th>Date created</th>
                        <th>Date updated</th>
                        <th v-if="getActiveUser['role']['role_name'] === 'auditor'">Record status</th>
                        <th v-if="getActiveUser['role']['role_name'] === 'procurement_officer' || getActiveUser['role']['role_name'] === 'top_executive'">Action</th>
                    </tr>
                </thead>

                <tbody v-if="getActiveUser['role']['role_name'] !== 'auditor'">
                    <tr v-for="application in activeApplications" :key="application['_id']['$oid']">
                        <td>{{ application.application_id }}</td>
                        <td>{{ application.product_name }}</td>
                        <td>{{ application.price }}</td>
                        <td>{{ application.created_by }}</td>
                        <td>{{ application.updated_by }}</td>
                        <td>{{ application.verified_by }}</td>
                        <td>{{ application.application_status }}</td>
                        <td>{{ application.notes }}</td>
                        <td>{{ application.date_created }}</td>
                        <td>{{ application.date_updated }}</td>
                        <td v-if="getActiveUser['role']['role_name'] === 'auditor'">{{ application.record_status }}</td>
                        <td v-if="getActiveUser['role']['role_name'] === 'procurement_officer' || getActiveUser['role']['role_name'] === 'top_executive'" class="d-flex">
                            <button class="btn btn-success" @click="showUpdateApplication(application)" :disabled="editBtnDisabled">{{ btnText }}</button>
                            <button class="btn btn-danger mx-1" @click.prevent="onDeleteApplication(application['_id']['$oid'])" :disabled="deleteBtnDisabled">delete</button>
                        </td>
                    </tr>
                </tbody>

                <tbody v-if="getActiveUser['role']['role_name'] === 'auditor'">
                    <tr v-for="application in allApplications" :key="application['_id']['$oid']">
                        <td>{{ application.application_id }}</td>
                        <td>{{ application.product_name }}</td>
                        <!-- <td>{{ application.currency.currency_name }}</td> -->
                        <td>{{ application.price }}</td>
                        <td>{{ application.created_by }}</td>
                        <td>{{ application.updated_by }}</td>
                        <td>{{ application.verified_by }}</td>
                        <td>{{ application.application_status }}</td>
                        <td>{{ application.notes }}</td>
                        <td>{{ application.date_created }}</td>
                        <td>{{ application.date_updated }}</td>
                        <td v-if="getActiveUser['role']['role_name'] === 'auditor'">{{ application.record_status }}</td>
                        <!-- <td>
                            <button class="btn btn-success" @click="showUpdateApplication(application)" :disabled="editBtnDisabled">{{ btnText }}</button>
                            <button class="btn btn-danger mx-1" @click.prevent="onDeleteApplication(application['_id']['$oid'])" :disabled="deleteBtnDisabled">delete</button>
                        </td> -->
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"

    import $ from "jquery"

    import AddApplication from "../../forms/add/AddApplication"
    import UpdateApplication from "../../forms/update/UpdateApplication"
    import VerifyApplication from "../../forms/update/VerifyApplication"

    export default{
        name: "Applications",

        components: {
            AddApplication,
            UpdateApplication,
            VerifyApplication,
        },

        data(){
            return{
                btnText: "edit",
                addBtnDisabled: true,
                uploadBtnDisabled: true,
                editBtnDisabled: true,
                deleteBtnDisabled: true,
                showActionButtons: true,
            }
        },

        methods: {
            ...mapActions(["fetchAllApplications", "deleteApplication", "searchApplications", "addApplicationEvent", "uploadApplications"]),

            showAddApplication(){
                $("#add-application").modal({show: true, backdrop: "static", keyboard: false})
            },

            showUpdateApplication(application){
                if(this.getActiveUser["role"]["role_name"] === "top_executive"){
                    $("#verify-application-form").attr("application-id", application["_id"]["$oid"])
                    $("#verify-product-name").val(application["product_name"])
                    // $("#verify-currency").val(application["currency"]["currency_name"])
                    $("#verify-price").val(application["price"])
                    $("#verify-application").modal({show: true, backdrop: "static", keyboard: false})
                }

                else if(this.getActiveUser["role"]["role_name"] === "procurement_officer"){
                    $("#update-application-form").attr("application-id", application["_id"]["$oid"])
                    $("#product-name").val(application["product_name"])
                    // $("#currency").val(application["currency"]["_id"]["$oid"])
                    $("#price").val(application["price"])
                    $("#update-application").modal({show: true, backdrop: "static", keyboard: false})
                }
            },

            onDeleteApplication(application_id){
                // this.deleteApplication(application_id)

                this.$swal({
                    title: "Delete Application?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes"
                }).then((response) => {
                    if(response.value == true){
                        // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})
                        $(".loader").addClass("spinner-border")
                        this.deleteApplication(application_id).then((response) => {
                            if(response.status == "success"){
                                this.$toast.show(`${response.message}`,
                                    {
                                        type: "success", 
                                        position: "top",
                                        duration: 4000,
                                    }
                                )
                            }

                            else if(response.status == "error"){
                                this.$toast.show(`There was a problem here`,
                                    {
                                        type: "error", 
                                        position: "top",
                                        duration: 4000,
                                    }
                                )
                            }
                            // $("#global-spinner").removeClass("spinner-grow")
                            // $("#loading-screen").modal("hide")
                            $(".loader").removeClass("spinner-border")
                        })
                    }
                })
            },

            async onUploadApplications(){
                $(".loader").addClass("spinner-border")

                await this.uploadApplications().then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                    }

                    $(".loader").removeClass("spinner-border")
                })
            }

            // onSearch(searchText){
            //     console.log(searchText)
            //     this.allApplications = this.allApplications.filter((app) => app.application_id.includes(searchText.toLocaleLowerCase()))
            // }
        },

        created(){
            this.fetchAllApplications()
            // this.fetchAllCurrencies()
            // this.addApplicationEvent()

            if(this.getActiveUser["role"]["role_name"] === "procurement_officer" || this.getActiveUser["role"]["role_name"] === "top_executive"){
                this.showActionButtons = true
            }

            else{
                this.showActionButtons = false
            }

            if(this.getActiveUser["role"]["role_name"] === "top_executive"){
                this.btnText = "verify"
            }

            if(this.getActiveUser["role"]["role_name"] === "procurement_officer" || this.getActiveUser["role"]["role_name"] === "top_executive" || this.getActiveUser["role"]["role_name"] === "auditor"){
                this.uploadBtnDisabled = true
            }

            else{
                this.uploadBtnDisabled = false
            }

            if(this.getActiveUser["role"]["role_name"] === "procurement_officer"){
                this.addBtnDisabled = true
            }

            else{
                this.addBtnDisabled = false
            }

            if(this.getActiveUser["role"]["role_name"] === "procurement_officer" || this.getActiveUser["role"]["role_name"] === "top_executive"){
                this.editBtnDisabled = false
                this.deleteBtnDisabled = false
            }

            else{
                this.editBtnDisabled = true
                this.deleteBtnDisabled = true
            }
        },

        mounted(){
            var channel = this.$pusher.subscribe('my-channels')
            channel.bind("my-event", obj => {
                // alert(obj.message)
                if(this.getActiveUser.first_name + " " + this.getActiveUser.last_name !== obj.data.full_name){
                    this.$toast.show(obj.data.message,
                        {
                            type: "info", 
                            position: "top",
                            duration: 8000,
                        }
                    )
                }
            })
        },

        computed: {
            ...mapGetters(["allApplications", "activeApplications", "getActiveUser"]),

            // searchApplications: function(){
            //     this.applications = this.applications.filter((app) => app.application_id.includes(this.searchText.toLocaleLowerCase()))
            //     return this.applications
            // }
        }
    }
</script>

<style scoped>
    /* APPLICATIONS TABLE */
    #applications{
        margin: 20px;
        /* border: solid 1px green; */
        min-height: 80vh;
        max-height: 80vh;
        overflow-y: scroll;
        box-shadow: 0 1px 1px rgba(0,0,0,0.12), 
                    0 2px 2px rgba(0,0,0,0.12), 
                    0 4px 4px rgba(0,0,0,0.12), 
                    0 8px 8px rgba(0,0,0,0.12),
                    0 16px 16px rgba(0,0,0,0.12);
    }

    .heading{
        display: flex;
        /* border: solid 1px blue; */
        margin: 10px 0;
    }

    hr{
        background: #1f1f1f;
    }

    .table-caption{
        margin: auto 10px auto 10px
    }

    .tools{
        margin-left: auto;
        padding: 10px 0;
        display: flex;
        /* border: solid 1px blue; */
    }

    .add-new-btn,
    .upload-btn{
        margin: auto 10px auto 10px;
        padding: 10px;
        
        /* width: 100%; */
        border: none;
        /* align-items: center; */
        outline: none;
    }

    .search-input{
        margin: auto 10px auto 10px;
        padding: 20px;
        
        /* width: 100%; */
        /* border: none; */
        /* align-items: center; */
        outline: none;
    }

    .table-container{
        overflow-x: scroll;
    }

    table, th, td{
    }
</style>