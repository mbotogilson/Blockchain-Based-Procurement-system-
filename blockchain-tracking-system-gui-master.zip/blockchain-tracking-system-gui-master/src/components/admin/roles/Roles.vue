<template>
    <AddRole />
    <UpdateRole />

    <div id="roles">
        <div class="heading text-dark">
            <h3 class="table-caption my-auto">Roles</h3>

            <div class="tools">
                <!-- <div class="fa fa-plus fa-2x center" title="add new"></div>
                <div class="fa fa-upload fa-2x center" title="upload to block chain"></div> -->

                <button v-if="getActiveUser['role']['role_name'] == 'admin'" class="add-new-btn btn btn-secondary" title="click to add new" @click.prevent="showAddRole" :disabled="addBtnDisabled">add</button>
                <!-- <button class="upload-btn btn btn-secondary" title="click to upload to block chain" disabled>upload</button> -->
            </div>
        </div>
        <hr>

        <div class="table-container">
            <table class="roles-table table table-striped">
                <thead class="bg-secondary text-white">
                    <tr>
                        <th>Role name</th>
                        <th v-if="getActiveUser['role']['role_name'] == 'admin'">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <tr v-for="role in allRoles" :key="role['_id']['$oid']">
                        <td>{{ role.role_name }}</td>
                        <td v-if="getActiveUser['role']['role_name'] === 'admin'" class="d-flex">
                            <button class="btn btn-success" @click.prevent="showUpdateRole(role)" :disabled="editBtnDisabled">edit</button>
                            <!-- <button class="btn btn-danger mx-1" disabled>delete</button> -->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"

    import $ from "jquery"

    import AddRole from "../../forms/add/AddRole"
    import UpdateRole from "../../forms/update/UpdateRole"

    export default{
        name: "Roles",

        components: {
            AddRole,
            UpdateRole,
        },

        data(){
            return{
                addBtnDisabled: true,
                editBtnDisabled: true,
            }
        },

        methods: {
            ...mapActions(["fetchAllRoles"]),

            showAddRole(){
                $("#add-role").modal({show: true, backdrop: "static", keyboard: false})
            },

            showUpdateRole(role){
                $("#update-role-form").attr("role-id", role["_id"]["$oid"])
                $("#role-name").val(role["role_name"])
                $("#update-role").modal({show: true, backdrop: "static", keyboard: false})
            }
        },

        created(){
            this.fetchAllRoles()

            if(this.getActiveUser["role"]["role_name"] === "admin"){
                this.addBtnDisabled = false
                this.editBtnDisabled = false
            }

            else{
                this.addBtnDisabled = true
                this.editBtnDisabled = true
            }
        },

        computed: mapGetters(["allRoles", "getActiveUser"]),

        mounted(){
            var channel = this.$pusher.subscribe('my-channels')
            channel.bind("my-event", obj => {
                // alert(obj.message)
                if(this.getActiveUser.first_name + " " + this.getActiveUser.last_name !== obj.data.full_name){
                    this.$toast.show(obj.data.message,
                        {
                            type: "info", 
                            position: "top",
                            duration: 8000,
                        }
                    )
                }
            })
        },
    }
</script>

<style scoped>
    /* APPLICATIONS TABLE */
    #roles{
        margin: 20px;
        /* border: solid 1px black; */
        min-height: 80vh;
        max-height: 80vh;
        overflow-y: scroll;
        box-shadow: 0 1px 1px rgba(0,0,0,0.12), 
                    0 2px 2px rgba(0,0,0,0.12), 
                    0 4px 4px rgba(0,0,0,0.12), 
                    0 8px 8px rgba(0,0,0,0.12),
                    0 16px 16px rgba(0,0,0,0.12);
    }

    .heading{
        display: flex;
        margin: 10px 0;
    }

    hr{
        background: #1f1f1f;
    }

    .table-caption{
        margin: auto 10px auto 10px
    }

    .tools{
        margin-left: auto;
        padding: 10px 0;
        display: flex;
    }

    .add-new-btn,
    .upload-btn{
        margin: auto 10px auto 10px;
        padding: 10px;
        
        /* width: 100%; */
        border: none;
        /* align-items: center; */
        outline: none;
    }

    table{
    }

    table, th, td{
    }
</style>