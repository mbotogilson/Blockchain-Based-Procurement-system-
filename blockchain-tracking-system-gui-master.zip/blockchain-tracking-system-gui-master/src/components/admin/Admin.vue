<template>
    <!-- <h1>Welcome to admin</h1> -->
    <NavBar @logoutUser="logout" />

    <router-view />
</template>

<script>
    import NavBar from "../layout/NavBar"

    export default{
        name: "Admin",

        components: {
            NavBar,
        },

        methods: {
            logout(){
                this.$router.replace({ path: "/" })
                window.localStorage.removeItem("vuex")
            }
        },

        // mounted(){
        //     var channel = this.$pusher.subscribe('my-channels')
        //     channel.bind("my-event", obj => {
        //         // alert(obj.message)
        //         if(this.getActiveUser.first_name + " " + this.getActiveUser.last_name !== obj.data.full_name){
        //             this.$toast.show(obj.data.message,
        //                 {
        //                     type: "info", 
        //                     position: "top",
        //                     duration: 8000,
        //                 }
        //             )
        //         }
        //     })
        // },
    }
</script>