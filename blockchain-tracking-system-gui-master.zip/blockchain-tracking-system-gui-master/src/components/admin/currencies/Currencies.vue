<template>
    <AddCurrency />
    <UpdateCurrency />

    <div id="currencies">
        <div class="heading text-dark">
            <h3>Currencies</h3>

            <div class="tools">
                <!-- <div class="fa fa-plus fa-2x center" title="add new"></div>
                <div class="fa fa-upload fa-2x center" title="upload to block chain"></div> -->

                <button class="add-new-btn btn btn-dark" title="add new" @click.prevent="showAddCurrency" :disabled="addBtnDisabled">add new</button>
                <button class="upload-btn btn btn-dark" title="upload to block chain" disabled>upload</button>
            </div>
        </div>

        <table class="currencies-table table table-dark table-striped">
            <thead>
                <tr>
                    <th>Currency name</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <tr v-for="currency in allCurrencies" :key="currency['_id']['$oid']">
                    <td>{{ currency.currency_name }}</td>
                    <td>
                        <button class="btn btn-success mx-1" @click.prevent="showUpdateCurrency(currency)" :disabled="editBtnDisabled">edit</button>
                        <button class="btn btn-danger mx-1" disabled>delete</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
    import { mapActions, mapGetters } from "vuex"

    import $ from "jquery"

    import AddCurrency from "../../forms/add/AddCurrency"
    import UpdateCurrency from "../../forms/update/UpdateCurrency"

    export default{
        name: "Currencies",

        components: {
            AddCurrency,
            UpdateCurrency,
        },

        data(){
            return{
                addBtnDisabled: true,
                editBtnDisabled: true,
            }
        },

        methods: {
            ...mapActions(["fetchAllCurrencies"]),

            showAddCurrency(){
                $("#add-currency").modal({show: true, backdrop: "static", keyboard: false})
            },

            showUpdateCurrency(currency){
                $("#update-currency-form").attr("currency-id", currency["_id"]["$oid"])
                $("#currency-name").val(currency["currency_name"])
                $("#update-currency").modal({show: true, backdrop: "static", keyboard: false})
            }
        },

        created(){
            this.fetchAllCurrencies()

            if(this.getActiveUser["role"]["role_name"] === "admin"){
                this.addBtnDisabled = false
                this.editBtnDisabled = false
            }

            else{
                this.addBtnDisabled = true
                this.editBtnDisabled = true
            }
        },

        computed: mapGetters(["allCurrencies", "getActiveUser"])
    }
</script>

<style scoped>
    /* APPLICATIONS TABLE */
    #currencies{
        margin: 10px;
        /* border: solid 1px black; */
        min-height: 80vh;
        max-height: 80vh;
        overflow-y: scroll;
    }

    .heading{
        display: flex;
    }

    .tools{
        margin-left: auto;
        padding: 10px 0;
        display: flex;
    }

    .add-new-btn,
    .upload-btn{
        margin: auto 0 auto 10px;
        padding: 10px;
        
        /* width: 100%; */
        border: none;
        /* align-items: center; */
        outline: none;
    }

    table{
    }

    table, th, td{
    }
</style>