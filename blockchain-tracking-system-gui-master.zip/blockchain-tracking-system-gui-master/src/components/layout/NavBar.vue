<template>
    <div class="layout">
        <nav class="bg-dark">
            <h2 class="my-auto">Financial Tracking</h2>
            <div class="loader"></div>
            <h3 id="active-user" class="dropdown dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{ getActiveUser.first_name }} {{ getActiveUser.last_name }}
                <div class="dropdown-menu" aria-labelledby="active-user">
                    <!-- <a class="dropdown-item" @click="showUpdateUserProfile(getActiveUser)">Update user profile</a> -->
                    <!-- <a class="dropdown-item" @click="$emit('logoutUser')">Logout</a> -->
                    <a class="dropdown-item text-dark bg-transparent" title="click to logout" @click="$emit('logoutUser')">Logout</a>
                    <!-- <a class="dropdown-item">CSV</a> -->
                </div>
            </h3>
        </nav>
    
        <div id="menu-nav">
            <router-link class="menu-nav m-0 to-applications" :class="activeApplications && theme" to="/applications" @click="activateApplications"><div>Applications</div></router-link>
            <!-- <router-link class="menu-nav m-0 to-currencies" :class="activeCurrencies && theme" to="/currencies" @click="activateCurrencies"><div>Currencies</div></router-link> -->
            <router-link class="menu-nav m-0 to-roles" :class="activeRoles && theme" to="/roles" @click="activateRoles"><div>Roles</div></router-link>
            <router-link class="menu-nav m-0 to-users" :class="activeUsers && theme" to="/users" @click="activateUsers"><div>Users</div></router-link>
        </div>
    </div>
</template>

<script>
    import { mapGetters } from "vuex"
    
    export default{
        name: "NavBar",

        data(){
            return{
                theme: "bg-dark",
                activeApplications: false,
                activeCurrencies: false,
                activeRoles: false,
                activeUsers: false,
            }
        },

        methods: {
            activateApplications(){
                this.activeApplications = true
                this.activeCurrencies = false
                this.activeRoles = false
                this.activeUsers = false
            },

            activateCurrencies(){
                this.activeApplications = false
                this.activeCurrencies = true
                this.activeRoles = false
                this.activeUsers = false
            },

            activateRoles(){
                this.activeApplications = false
                this.activeCurrencies = false
                this.activeRoles = true
                this.activeUsers = false
            },
            
            activateUsers(){
                this.activeApplications = false
                this.activeCurrencies = false
                this.activeRoles = false
                this.activeUsers = true
            },
        },

        computed: mapGetters(["getActiveUser"]),

        created(){
            if(this.$route.name === "Applications"){
                this.activeApplications = true
                this.activeCurrencies = false
                this.activeRoles = false
                this.activeUsers = false
            }

            else if(this.$route.name === "Currencies"){
                this.activeCurrencies = true
                this.activeApplications = false
                this.activeRoles = false
                this.activeUsers = false
            }

            else if(this.$route.name === "Roles"){
                this.activeRoles = true
                this.activeApplications = false
                this.activeCurrencies = false
                this.activeUsers = false
            }

            else if(this.$route.name === "Users"){
                this.activeUsers = true
                this.activeCurrencies = false
                this.activeCurrencies = false
                this.activeRoles = false
            }
        }
    }

</script>

<style scoped>
    /* MAIN NAV SECTION */
    nav{
        color: white;
        display: flex;
        padding: 5px;
        max-height: 10vh;
        min-height: 10vh;
    }

    nav h1{
        margin-left: 10px;
    }

    /* nav h3{
        margin: auto 10px auto auto;
    } */

    nav h3{
        margin: auto 10px auto 0;
    }

    nav .loader{
        margin: auto 10px auto auto;
    }

    /* MENU NAV SECTION */
    #menu-nav{
        background: #858585;
        display: grid;
        grid-template-columns: 4fr 4fr 4fr;
        max-height: 10vh;
    }

    .menu-nav{
        text-decoration: none;
        color: #EEF2F7;
        text-align: center;
        padding: 10px;
        /* border: solid 1px white; */
        font-weight: bold;
        margin: 5px;
    }

    .menu-nav:hover{
        background: #1f1f1f;
        transition: 0.8s;
        cursor: pointer;
    }

    .dropdown-item{
        cursor: pointer;
    }

    /* #to-applications,
    #currencies,
    #{
        text-decoration: none;
        color: white;
    } */
</style>