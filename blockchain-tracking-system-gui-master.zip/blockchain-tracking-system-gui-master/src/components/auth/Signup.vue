<template>
    <!-- <LoadingScreen /> -->

    <div class="row">
        <div class="modal fade" id="signup">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title">
                            <h3 class="text-dark">Signup</h3>
                        </div>

                        <button type="button" className="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form id="signup-form">
                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">First name:</label>
                                <input v-model="first_name" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="First name"><br>
                            </div>

                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Last name:</label>
                                <input v-model="last_name" class="form-control shadow-none w-100 m-2" type="text" required="1" placeholder="Last name"><br>
                            </div>

                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Email:</label>
                                <input v-model="email" class="form-control shadow-none w-100 m-2" type="email" required placeholder="Email"><br>
                            </div>

                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Password:</label>
                                <input v-model="password" class="form-control shadow-none w-100 m-2" type="password" required placeholder="Password"><br>
                            </div>

                            <div class="row form-group">
                                <label class="m-2 text-dark font-weight-bold">Confirm password:</label>
                                <input v-model="confirm_password" class="form-control shadow-none w-100 m-2" type="password" required placeholder="Confirm password"><br>
                            </div>

                            <!-- <div class="row form-group">
                                <select v-model="employee_type" class="form-control shadow-none w-100 m-2" required placeholder="Employee type">
                                    <option disabled>Employee type</option>
                                    <option value="Accountant">Accountant</option>
                                    <option value="Receptionist">Receptionist</option>
                                    <option value="CFO">CFO</option>
                                    <option value="COO">COO</option>
                                    <option value="Managing Director">Managing Director</option>
                                </select>
                            </div> -->

                            <div class="row form-group">
                                <button @click.prevent="onSignup" class="btn btn-dark w-100 m-2 font-weight-bold">Signup</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions } from "vuex"
    import $ from "jquery"
    // import LoadingScreen from "../layout/LoadingScreen"

    export default{
        name: "Signup",

        components: {
            // LoadingScreen
        },

        data(){
            return{
                user: {
                    first_name: "",
                    last_name: "",
                    email: "",
                    password: "",
                    confirm_password: "",
                }
            }
        },

        methods: {
            ...mapActions(["signup"]),

            async onSignup(){
                if(this.password === this.confirm_password){
                    let user = {
                        "first_name": this.first_name,
                        "last_name": this.last_name,
                        "email": this.email,
                        "password": this.password,
                    }

                    $(".login-spinner").addClass("spinner-border")
                    $("#signup").modal("hide")
                    // $("#loading-screen").modal({show: true, backdrop: "static", keyboard: false})

                    await this.signup(user).then((response) => {
                        if(response.status == "success"){
                            this.$toast.show(`${response.message}`,
                                {
                                    type: "success", 
                                    position: "top",
                                    duration: 4000,
                                }
                            )

                            // Modal
                            $("#signup").modal("hide")
                            $("#signup-form").trigger("reset")
                        }

                        else if(response.message == "error"){
                            this.$toast.show(`${response.message}`,
                                {
                                    type: "error", 
                                    position: "top",
                                    duration: 4000,
                                }
                            )

                            $("#signup").modal("show")
                        }

                        // $("#signup-spinner").removeClass("spinner-grow")
                        // $("#loading-screen").modal("hide")
                        $(".login-spinner").removeClass("spinner-border")
                    })
                }

                else{
                    this.$toast.show("You passwords do not match",
                        {
                            type: "error", 
                            position: "top",
                            duration: 4000,
                        }
                    )
                }
            }
        }
    }
</script>

<style>
</style>