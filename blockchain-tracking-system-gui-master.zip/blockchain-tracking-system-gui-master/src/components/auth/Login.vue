<template>
    <Signup />

    <div class="auth-page d-flex">
        <div class="login-page my-auto">
            <div class="welcome-note my-auto">
                <h1>Blockchain Based Financial Administration Tracking System</h1>
            </div>

            <div class="login-section">
                <div class="login p-3">
                    <div class="row">
                        <div class="card mx-auto col-10">
                            <div class="card-header bg-white">
                                <div class="card-title">
                                    <h3 class="text-dark">Login<span class="login-spinner"></span></h3>
                                </div>
                            </div>

                            <div class="card-body">
                                <form class="p-1">
                                    <div class="row form-group">
                                        <label class="my-1 text-dark font-weight-bold">Email:</label>
                                        <input v-model="email" class="form-control shadow-none mx-auto w-100" type="email" placeholder="Email" required><br>
                                    </div>

                                    <div class="row form-group">
                                        <label class="my-1 text-dark font-weight-bold">Password:</label>
                                        <input v-model="password" class="form-control shadow-none mx-auto w-100 m-1" type="password" placeholder="Password" required><br>
                                    </div>

                                    <div class="row form-group">
                                        <button @click.prevent="onLogin" class="btn btn-dark w-100 my-1 mx-auto font-weight-bold">Login</button>
                                    </div>

                                    <div class="row form-group">
                                        <button @click.prevent="showSignupForm" class="btn btn-outline-secondary w-50 my-1 mx-auto font-weight-bold">Signup</button>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { mapActions } from "vuex"

    import $ from "jquery"

    import Signup from "./Signup"

    export default{
        name: "Login",

        components: {
            Signup
        },

        data(){
            return{
                user: {
                    email: "",
                    password: ""
                }
            }
        },

        methods: {
            ...mapActions(["login"]),

            async onLogin(){
                let user = {
                    email: this.email,
                    password: this.password
                }

                $(".login-spinner").addClass("spinner-border")
                await this.login(user).then((response) => {
                    if(response.status == "success"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "success", 
                                position: "top",
                                duration: 4000,
                            }
                        )

                        this.$router.push({name: "Applications"})
                    }

                    else if(response.status == "error"){
                        this.$toast.show(`${response.message}`,
                            {
                                type: "error", 
                                position: "top",
                                duration: 4000,
                            }
                        )
                        // $("#updateRoleUser").modal("show")
                        $(".login-spinner").removeClass("spinner-border")
                    }
                })
            },

            showSignupForm(){
                $("#signup").modal({show: true, backdrop: "static", keyboard: false})
            }
        },
    }

</script>

<style scoped>
    .auth-page{
        min-height: 100vh;
        /* border: solid 5px red; */
    }

    .login-page{
        display: grid;
        grid-template-columns: 5fr 7fr;
        /* border: solid 5px black; */
    }

    .welcome-note{
        /* border: solid 1px blue; */
        text-align: center;
    }

    .login-section{
        /* border: solid 1px blue; */
    }

    /* .card{
        box-shadow: rgba(0,0,0,0.2) 0 6px 6px;
    } */

    .card {
        box-shadow: 0 1px 1px rgba(0,0,0,0.12), 
                    0 2px 2px rgba(0,0,0,0.12), 
                    0 4px 4px rgba(0,0,0,0.12), 
                    0 8px 8px rgba(0,0,0,0.12),
                    0 16px 16px rgba(0,0,0,0.12);
    }
</style>
