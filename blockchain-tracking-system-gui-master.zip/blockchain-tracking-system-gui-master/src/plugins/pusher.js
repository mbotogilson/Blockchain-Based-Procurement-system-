export default (app, { api_key, ...options }) => {
    // const Pusher = require('pusher-js')
    const Pusher = require('pusher-js')
    app.config.globalProperties.$pusher = new Pusher(api_key, options)
}