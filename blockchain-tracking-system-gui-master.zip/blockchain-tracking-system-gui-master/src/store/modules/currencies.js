import axios from "axios"

const state = {
    currencies: [],
}

const getters = {
    allCurrencies: (state) => state.currencies
}

const actions = {
    async fetchAllCurrencies({ commit }){
        try{
            const response = await axios.get("get_currencies")

            if(response.data.status == "success"){
                let currencies = response.data.data.currencies
                console.log(currencies)

                commit("setAllCurrencies", currencies)
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async addCurrency({ commit }, currency){
        let currency_name = currency["currency_name"]

        try{
            const response = await axios.post("add_currency", {currency_name})

            if(response.data.status == "success"){
                currency = response.data.data
                commit("setNewCurrency", currency)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async updateCurrency({ commit }, currency){
        let currency_id = currency["id"]
        let currency_name = currency["currency_name"]

        try{
            const response = await axios.put("update_currency", {currency_id, currency_name})

            if(response.data.status == "success"){
                currency = response.data.data
                console.log(currency)
                commit("setUpdatedCurrency", currency)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    }
}

const mutations = {
    setAllCurrencies: (state, currencies) => (state.currencies = currencies),
    setNewCurrency: (state, currency) => (state.currencies.push(currency)),
    setUpdatedCurrency: (state, updated_currency) => {
        const index = state.currencies.findIndex(currency => currency._id.$oid === updated_currency._id.$oid)

        if(index !== -1){
            state.currencies.splice(index, 1, updated_currency)
        }
    },
}

export default{
    state,
    getters,
    actions,
    mutations
}