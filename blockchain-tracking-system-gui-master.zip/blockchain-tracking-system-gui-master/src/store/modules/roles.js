import axios from "axios"

const state = {
    roles: [],
}

const getters = {
    allRoles: (state) => state.roles
}

const actions = {
    async fetchAllRoles({ commit }){
        try{
            const response = await axios.get("get_roles")

            if(response.data.status == "success"){
                let roles = response.data.data.roles
                console.log(roles)

                commit("setAllRoles", roles)
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async addRole({ commit }, role){
        let role_name = role["role_name"]

        try{
            const response = await axios.post("add_role", {role_name})

            if(response.data.status == "success"){
                role = response.data.data
                commit("setNewRole", role)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async updateRole({ commit }, role){
        let role_id = role["id"]
        let role_name = role["role_name"]

        try{
            const response = await axios.put("update_role", {role_id, role_name})

            if(response.data.status == "success"){
                role = response.data.data
                console.log(role)
                commit("setUpdatedRole", role)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    }
}

const mutations = {
    setAllRoles: (state, roles) => (state.roles = roles),
    setNewRole: (state, role) => (state.roles.push(role)),
    setUpdatedRole: (state, updated_role) => {
        const index = state.roles.findIndex(role => role._id.$oid === updated_role._id.$oid)

        if(index !== -1){
            state.roles.splice(index, 1, updated_role)
        }
    },
}

export default{
    state,
    getters,
    actions,
    mutations
}