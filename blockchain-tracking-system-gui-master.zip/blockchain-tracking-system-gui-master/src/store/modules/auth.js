import axios from "axios"

const state = {
    activeUser: {},
    authenticated: false,
}

const getters = {
    isAuthenticated: (state) => state.authenticated,
    getActiveUser: (state) => state.activeUser
}

const actions = {
    async login({ commit }, user){
        let email = user["email"]
        let password = user["password"]
        console.log(user)

        try{
            const response = await axios.post("login", {email, password})
            console.log(response.data)

            if(response.data.status == "success"){
                commit("authenticateUser", true)
                commit("setActiveUser", response.data.data)
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async signup({ commit }, user){
        let first_name = user["first_name"]
        let last_name = user["last_name"]
        let email = user["email"]
        let password = user["password"]
        console.log(user)

        try{
            const response = await axios.post("signup", {first_name, last_name, email, password})
            console.log(response.data)

            if(response.data.status == "success"){
                commit("confirmSignup")
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    }
}

const mutations = {
    authenticateUser: (state, value) => (state.authenticated = value),
    setActiveUser: (state, user) => (state.activeUser = user),
    confirmSignup: () => "signup done",
}

export default{
    state,
    getters,
    actions,
    mutations
}