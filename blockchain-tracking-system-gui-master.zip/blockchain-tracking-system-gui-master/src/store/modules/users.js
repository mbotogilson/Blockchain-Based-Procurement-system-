import axios from "axios"

const state = {
    users: [],
}

const getters = {
    allUsers: (state) => state.users
}

const actions = {
    async fetchAllUsers({ commit }){
        try{
            const response = await axios.get("get_users")

            if(response.data.status == "success"){
                let users = response.data.data.users
                console.log(users)

                commit("setAllUsers", users)
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async changeUserRole({ commit }, user){
        let user_id = user["id"]
        let role = user["role"]

        try{
            const response = await axios.put("change_user_role", {user_id, role})

            if(response.data.status == "success"){
                user = response.data.data
                commit("setUpdatedUserRole", user)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async deleteUser({ commit }, user_id){
        // console.log(application)
        try{
            const response = await axios.delete(`delete_user/${user_id}`)

            if(response.data.status == "success"){
                let user = response.data.data
                console.log(user)
                commit("removeDeletedUser", user)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    }
}

const mutations = {
    setAllUsers: (state, users) => (state.users = users),
    // setNewRole: (state, role) => (state.roles.push(role)),
    setUpdatedUserRole: (state, updated_user_role) => {
        const index = state.users.findIndex(user => user._id.$oid === updated_user_role._id.$oid)

        if(index !== -1){
            state.users.splice(index, 1, updated_user_role)
        }
    },
    removeDeletedUser: (state, deleted_user) => (state.users = state.users.filter(user => user._id.$oid !== deleted_user._id.$oid))
}

export default{
    state,
    getters,
    actions,
    mutations
}