import axios from "axios"

const state = {
    universal_applications: [],
    applications: [],
}

const getters = {
    allApplications: (state) => state.applications,
    activeApplications: (state) => state.applications.filter(app => app.record_status === "ACTIVE")
}

const actions = {
    async fetchAllApplications({ commit }){
        try{
            const response = await axios.get("get_applications")

            if(response.data.status == "success"){
                let applications = response.data.data.applications
                console.log(applications)

                commit("setAllApplications", applications)
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async addApplication({ commit }, application){
        let product_name = application["product_name"]
        // let currency = application["currency"]
        let price = parseFloat(application["price"])
        let created_by = application["created_by"]

        try{
            const response = await axios.post("add_application", {product_name, price, created_by})

            if(response.data.status == "success"){
                application = response.data.data
                console.log(application)
                commit("setNewApplication", application)
                // commit("setNewUniversalApplication", application)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async updateApplication({ commit }, application){
        let application_id = application["id"]
        let product_name = application["product_name"]
        // let currency = application["currency"]
        let price = parseFloat(application["price"])
        let updated_by = application["updated_by"]

        try{
            const response = await axios.put("update_application", {application_id, product_name, price, updated_by})

            if(response.data.status == "success"){
                application = response.data.data
                console.log(application)
                commit("setUpdatedApplication", application)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async verifyApplication({ commit }, application){
        let application_id = application["id"]
        let application_status = application["application_status"]
        let verified_by = application["verified_by"]
        let notes = application["notes"]

        console.log(application)

        try{
            const response = await axios.put("verify_application", {application_id, application_status, notes, verified_by})

            if(response.data.status == "success"){
                application = response.data.data
                console.log(application)
                commit("setVerifiedApplication", application)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    async deleteApplication({ commit }, application_id){
        // console.log(application)
        try{
            const response = await axios.delete(`delete_application/${application_id}`)

            if(response.data.status == "success"){
                let application = response.data.data
                console.log(application)
                commit("removeDeletedApplication", application)

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },

    searchApplications({ commit }, searchText){
        commit("computeSearchProcess", searchText)
    },

    async uploadApplications({ commit }){
        try{
            const response = await axios.get("upload_applications")

            if(response.data.status == "success"){
                commit("setUploadedApplications")

                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }

            else{
                return{
                    "status": `${response.data.status}`,
                    "message": `${response.data.message}`,
                }
            }
        }

        catch(e){
            console.log(e)
            return{
                "status": `error`,
                "message": `Sorry we are experiencing some technical incoveniences`,
            }
        }
    },
}

const mutations = {
    setAllApplications: (state, applications) => {
        state.universal_applications = applications
        state.applications = state.universal_applications
    },

    setNewApplication: (state, application) => {
        state.applications.push(application)
        state.universal_applications = state.applications
    },

    // setNewUniversalApplication: (state, application) => {
    //     state.universal_applications.push(application)
    // },

    setUpdatedApplication: (state, updated_application) => {
        const universal_index = state.universal_applications.findIndex(application => application._id.$oid === updated_application._id.$oid)

        if(universal_index !== -1){
            state.universal_applications.splice(universal_index, 1, updated_application)
        }

        const index = state.applications.findIndex(application => application._id.$oid === updated_application._id.$oid)

        if(index !== -1){
            state.applications.splice(index, 1, updated_application)
        }
    },

    setVerifiedApplication: (state, verified_application) => {
        const universal_index = state.universal_applications.findIndex(application => application._id.$oid === verified_application._id.$oid)

        if(universal_index !== -1){
            state.universal_applications.splice(universal_index, 1, verified_application)
        }

        const index = state.applications.findIndex(application => application._id.$oid === verified_application._id.$oid)

        if(index !== -1){
            state.applications.splice(index, 1, verified_application)
        }
    },

    removeDeletedApplication: (state, deleted_application) => {
        state.universal_applications = state.universal_applications.filter(application => application._id.$oid !== deleted_application._id.$oid)

        state.applications = state.applications.filter(application => application._id.$oid !== deleted_application._id.$oid)
    },

    computeSearchProcess: (state, searchText) => (state.applications = state.universal_applications.filter((app) =>
        app.application_id.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.product_name.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        // app.currency.currency_name.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.created_by.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.updated_by.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.verified_by.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.application_status.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.notes.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.date_created.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.date_updated.toLocaleLowerCase().includes(searchText.toLocaleLowerCase()) ||
        app.record_status.toLocaleLowerCase().includes(searchText.toLocaleLowerCase())
    )),

    setUploadedApplications: () => null,
}

export default{
    state,
    getters,
    actions,
    mutations
}