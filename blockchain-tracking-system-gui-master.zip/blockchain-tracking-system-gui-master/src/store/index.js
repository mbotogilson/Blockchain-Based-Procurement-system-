import { createStore } from "vuex"
import VuexPersistence from "vuex-persist"

import auth from "./modules/auth"
import applications from "./modules/applications"
import currencies from "./modules/currencies"
import roles from "./modules/roles"
import users from "./modules/users"

const vuexLocal = new VuexPersistence({
    storage: window.localStorage
})
  
const store = createStore({
    modules: {
        auth: auth,
        applications: applications,
        currencies: currencies,
        roles: roles,
        users: users,
    },

    plugins: [vuexLocal.plugin]
})

export default store