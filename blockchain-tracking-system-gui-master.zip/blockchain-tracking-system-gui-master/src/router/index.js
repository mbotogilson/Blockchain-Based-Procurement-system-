import { createRouter, createWebHistory } from "vue-router"

import store from "@/store"

import Login from "../components/auth/Login"
import Admin from "../components/admin/Admin"
import Applications from "../components/admin/applications/Applications"
import Currencies from "../components/admin/currencies/Currencies"
import Roles from "../components/admin/roles/Roles"
import Users from "../components/admin/users/Users"

const routes = [
    {
        path: "/",
        name: "Login",
        component: Login
    },

    {
        path: "/admin",
        name: "Admin",
        component: Admin,
        children: [
            {
                path: "/users",
                name: "Users",
                component: Users
            },

            {
                path: "/applications",
                name: "Applications",
                component: Applications
            },

            {
                path: "/currencies",
                name: "Currencies",
                component: Currencies
            },

            {
                path: "/roles",
                name: "Roles",
                component: Roles
            },

            {
                path: "/users",
                name: "Users",
                component: Users
            },
        ]
    },
]

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes,
    mode: "history"
})

router.beforeEach((to, from, next) => {
    let isAuthenticated = store.getters.isAuthenticated
    // let activeUser = store.getters.getActiveUser

    if(to.name !== "Login"){
        if(!isAuthenticated){
            next({ name: "Login" })
        }

        // if(activeUser !== {}){
        //     next({ name: "Login" })
        // }

        else{
            next()
        }
    }

    else{
        next()
    }

    
})

export default router