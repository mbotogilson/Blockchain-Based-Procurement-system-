import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

delete_user_blueprint = Blueprint("delete_user_blueprint", __name__)

@delete_user_blueprint.route("/delete_user/<user_id>", methods=["DELETE"])
def delete_user(user_id):
    # request_data = request.json
    # print(user_id)

    try:
        mongo.db.users.update_one({
                "_id": ObjectId(user_id),
            },

            {"$set":{
                "record_status": "DELETED",
            }
        })


        user = mongo.db.users.find_one({"_id": ObjectId(user_id)})
        user = json.loads(dumps(user))
        print(user)

        return jsonify({
            "status": "success",
            "message": "You have successfully deleted {} {}".format(user["first_name"], user["last_name"]),
            "data": user
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })