import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

change_user_role_blueprint = Blueprint("change_user_role_blueprint", __name__)

@change_user_role_blueprint.route("/change_user_role", methods=["PUT"])
def change_user_role():
    request_data = request.json

    try:
        mongo.db.users.update_one({
                "_id": ObjectId(request_data["user_id"]),
            },

            {"$set":{
                "role": request_data["role"],
            }
        })

        user = mongo.db.users.find_one({"_id": ObjectId(request_data["user_id"])})
        user = json.loads(dumps(user))

        role = mongo.db.roles.find_one({"_id": ObjectId(user["role"])})
        role = json.loads(dumps(role))
        user["role"] = role
        
        return jsonify({
            "status": "success",
            "message": "{} {}'s role was successfully changed to {}".format(user["first_name"], user["last_name"], role["role_name"]),
            "data": user
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })