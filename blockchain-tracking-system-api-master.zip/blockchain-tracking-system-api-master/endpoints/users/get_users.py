import json

from flask import Blueprint, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

get_users_blueprint = Blueprint("get_users_blueprint", __name__)

@get_users_blueprint.route("/get_users", methods=["GET"])
def get_users():
    try:
        users = mongo.db.users.find({"record_status": {"$ne": "DELETED"}}, {"password": 0})
        users = json.loads(dumps(users))

        if len(users) < 1:
            return jsonify({
                "status": "error",
                "message": "Sorry no users found.",
            })

        else:
            for user in users:
                role = mongo.db.roles.find_one({"_id": ObjectId(user["role"])})
                role = json.loads(dumps(role))
                user["role"] = role

            print(users)

            return jsonify({
                "status": "success",
                "message": "users were successfully retrieved.",
                "data": {
                    "users": users
                }
            })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })