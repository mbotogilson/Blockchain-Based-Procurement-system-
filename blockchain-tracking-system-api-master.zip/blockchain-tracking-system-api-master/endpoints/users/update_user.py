import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

update_user_blueprint = Blueprint("update_user_blueprint", __name__)

@update_user_blueprint.route("/update_user", methods=["PUT"])
def update_user():
    request_data = request.json

    try:
        mongo.db.users.update_one({
                "_id": ObjectId(request_data["user_id"]),
            },

            {"$set":{
                "first_name": request_data["first_name"],
                "last_name": request_data["last_name"],
                "email": request_data["email"],
                "password": request_data["password"],
            }
        })

        user = mongo.db.users.find_one({"_id": ObjectId(request_data["user_id"])})
        user = json.loads(dumps(user))
        
        return jsonify({
            "status": "success",
            "message": "{} {} was successfully updated".format(user["first_name"], user["last_name"]),
            "data": user,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })