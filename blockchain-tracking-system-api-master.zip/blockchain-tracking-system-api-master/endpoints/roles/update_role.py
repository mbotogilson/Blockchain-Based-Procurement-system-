import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

update_role_blueprint = Blueprint("update_role_blueprint", __name__)

@update_role_blueprint.route("/update_role", methods=["PUT"])
def update_role():
    request_data = request.json

    try:
        mongo.db.roles.update_one({
                "_id": ObjectId(request_data["role_id"]),
            },

            {"$set":{
                "role_name": request_data["role_name"],
            }
        })

        role = mongo.db.roles.find_one({"_id": ObjectId(request_data["role_id"])})
        role = json.loads(dumps(role))
        
        return jsonify({
            "status": "success",
            "message": "You have successfully updated {} role".format(role["role_name"]),
            "data": role,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })