import json

from flask import Blueprint, jsonify
from bson.json_util import dumps

from database.database import mongo

get_roles_blueprint = Blueprint("get_roles_blueprint", __name__)

@get_roles_blueprint.route("/get_roles", methods=["GET"])
def get_roles():
    try:
        roles = mongo.db.roles.find()
        roles = json.loads(dumps(roles))

        if len(roles) < 1:
            return jsonify({
                "status": "error",
                "message": "Sorry no roles found.",
            })

        else:
            return jsonify({
                "status": "success",
                "message": "roles were successfully retrieved.",
                "data": {
                    "roles": roles
                }
            })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })