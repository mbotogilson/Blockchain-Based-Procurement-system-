import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId

from database.database import mongo

delete_role_blueprint = Blueprint("delete_role_blueprint", __name__)

@delete_role_blueprint.route("/delete_role", methods=["DELETE"])
def delete_role():
    request_data = request.json

    try:
        mongo.db.roles.update_one({
                "_id": ObjectId(request_data["role_id"]),
            },

            {"$set":{
                "record_status": "DELETED",
            }
        })

        return jsonify({
            "status": "success",
            "message": "You have successfully deleted {} role".format(request_data["role_name"])
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })