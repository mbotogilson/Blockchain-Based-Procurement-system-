import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps
from database.database import mongo

add_role_blueprint = Blueprint("add_role_blueprint", __name__)

@add_role_blueprint.route("/add_role", methods=["POST"])
def add_role():
    request_data = request.json

    try:
        role_id = mongo.db.roles.insert({
            "role_name": request_data["role_name"],
            "record_status": "ACTIVE"
        })

        role = mongo.db.roles.find_one({"_id": ObjectId(role_id)})
        role = json.loads(dumps(role))

        return jsonify({
            "status": "success",
            "message": "You have successfully added {} role".format(role["role_name"]),
            "data": role,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })