import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

update_currency_blueprint = Blueprint("update_currency_blueprint", __name__)

@update_currency_blueprint.route("/update_currency", methods=["PUT"])
def update_currency():
    request_data = request.json

    try:
        mongo.db.currencies.update_one({
                "_id": ObjectId(request_data["currency_id"]),
            },

            {"$set":{
                "currency_name": request_data["currency_name"],
            }
        })

        currency = mongo.db.currencies.find_one({"_id": ObjectId(request_data["currency_id"])})
        currency = json.loads(dumps(currency))
        
        return jsonify({
            "status": "success",
            "message": "You have successfully updated {} currency".format(currency["currency_name"]),
            "data": currency,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })