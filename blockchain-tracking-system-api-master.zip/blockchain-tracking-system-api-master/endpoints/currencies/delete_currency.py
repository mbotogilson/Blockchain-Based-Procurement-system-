import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId

from database.database import mongo

delete_currency_blueprint = Blueprint("delete_currency_blueprint", __name__)

@delete_currency_blueprint.route("/delete_currency", methods=["DELETE"])
def delete_currency():
    request_data = request.json

    try:
        mongo.db.currencies.update_one({
                "_id": ObjectId(request_data["currency_id"]),
            },

            {"$set":{
                "record_status": "DELETED",
            }
        })

        return jsonify({
            "status": "success",
            "message": "You have successfully deleted {} currency".format(request_data["currency_name"])
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })