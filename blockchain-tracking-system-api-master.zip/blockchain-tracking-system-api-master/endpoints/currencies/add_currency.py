import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps
from database.database import mongo

add_currency_blueprint = Blueprint("add_currency_blueprint", __name__)

@add_currency_blueprint.route("/add_currency", methods=["POST"])
def add_currency():
    request_data = request.json

    try:
        currency_id = mongo.db.currencies.insert({
            "currency_name": request_data["currency_name"],
            "record_status": "ACTIVE"
        })

        currency = mongo.db.currencies.find_one({"_id": ObjectId(currency_id)})
        currency = json.loads(dumps(currency))

        return jsonify({
            "status": "success",
            "message": "You have successfully added {} currency".format(currency["currency_name"]),
            "data": currency,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })