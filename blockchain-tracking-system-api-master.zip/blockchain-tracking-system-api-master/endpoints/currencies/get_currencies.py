import json

from flask import Blueprint, jsonify
from bson.json_util import dumps

from database.database import mongo

get_currencies_blueprint = Blueprint("get_currencies_blueprint", __name__)

@get_currencies_blueprint.route("/get_currencies", methods=["GET"])
def get_currencies():
    try:
        currencies = mongo.db.currencies.find()
        currencies = json.loads(dumps(currencies))

        if len(currencies) < 1:
            return jsonify({
                "status": "error",
                "message": "Sorry no currencies found.",
            })

        else:
            return jsonify({
                "status": "success",
                "message": "currencies were successfully retrieved.",
                "data": {
                    "currencies": currencies
                }
            })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })