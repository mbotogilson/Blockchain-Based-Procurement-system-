import json

from flask import Blueprint, request, jsonify
from flask_cors import CORS

from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

login_blueprint = Blueprint("login_blueprint", __name__)
CORS(login_blueprint)

@login_blueprint.route("/login", methods=["POST"])
def login():
    request_data = request.json
    print(request_data)

    try:
        user = mongo.db.users.find_one({"$and": [{"email": request_data["email"]}, {"record_status": {"$ne": "DELETED"}}]})
        user = json.loads(dumps(user))

        if user:
            if user["password"] == request_data["password"]:
                role = mongo.db.roles.find_one({"_id": ObjectId(user["role"])})
                role = json.loads(dumps(role))
                user["role"] = role

                return jsonify({
                    "status": "success",
                    "message": "You successfully logged in as {} {}.".format(user["first_name"], user["last_name"]),
                    "data": user
                })

            else:
                return jsonify({
                    "status": "error",
                    "message": "Incorrect credentials."
                })

        else:
            return jsonify({
                "status": "error",
                "message": "Incorrect credentials."
            })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })