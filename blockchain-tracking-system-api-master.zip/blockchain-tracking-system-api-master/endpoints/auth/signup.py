import json

from flask import Blueprint, request, jsonify
from bson.json_util import dumps

from database.database import mongo

signup_blueprint = Blueprint("signup_blueprint", __name__)

@signup_blueprint.route("/signup", methods=["POST"])
def signup():
    request_data = request.json

    role = mongo.db.roles.find_one({"role_name": "user"})
    role = json.loads(dumps(role))

    try:
        user = mongo.db.users.insert({
            "first_name": request_data["first_name"],
            "last_name": request_data["last_name"],
            "email": request_data["email"],
            "password": request_data["password"],
            "role": role["_id"]["$oid"],
            "record_status": "ACTIVE"
            # "sex": request_data["sex"],
        })

        print(user)

        return jsonify({
            "status": "success",
            "message": "Congratulations, you successfully registered as {} {}".format(request_data["first_name"], request_data["last_name"])
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })