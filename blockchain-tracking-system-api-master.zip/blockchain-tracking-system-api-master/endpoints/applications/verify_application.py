import json
import pusher

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

verify_application_blueprint = Blueprint("verify_application_blueprint", __name__)

pusher_client = pusher.Pusher(
  app_id='1220070',
  key='0139f6a50e684ba36682',
  secret='092daabda8c2c9031b2f',
  cluster='mt1',
  ssl=True
)

@verify_application_blueprint.route("/verify_application", methods=["PUT"])
def verify_application():
    request_data = request.json

    try:
        mongo.db.applications.update_one({
                "_id": ObjectId(request_data["application_id"]),
            },

            {"$set":{
                # "product_name": request_data["product_name"],
                "application_status": request_data["application_status"],
                "verified_by": request_data["verified_by"],
                "notes": request_data["notes"],
            }
        })

        application = mongo.db.applications.find_one({"_id": ObjectId(request_data["application_id"])})
        application = json.loads(dumps(application))

        # currency = mongo.db.currencies.find_one({"_id": ObjectId(application["currency"])})
        # currency = json.loads(dumps(currency))
        # application["currency"] = currency

        pusher_client.trigger('my-channels', 'my-event', {
            "data": {
                "full_name": application["verified_by"],
                'message': '{} verified {} application to {}, please refresh your page'.format(application["verified_by"], application["application_id"], application["application_status"])
            }
        })

        return jsonify({
            "status": "success",
            "message": "You have successfully verified {} application".format(application["product_name"]),
            "data": application,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })