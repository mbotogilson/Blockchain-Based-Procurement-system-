import json

from datetime import datetime

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps
from database.database import mongo

add_application_blueprint = Blueprint("add_application_blueprint", __name__)

@add_application_blueprint.route("/add_application", methods=["POST"])
def add_application():
    request_data = request.json
    print(type(request_data))

    apps = mongo.db.applications.find()
    apps = json.loads(dumps(apps))
    apps_count = len(apps)
    count = apps_count + 1
    
    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d, %H:%M:%S")
    
    year = now.strftime("%Y")
    year = year[-2:]

    application_id = "BFTS" + year + str(count)
    print(application_id)

    try:
        application_id = mongo.db.applications.insert({
            "application_id": application_id,
            "product_name": request_data["product_name"],
            # "currency": request_data["currency"],
            "price": request_data["price"],
            "created_by": request_data["created_by"],
            "updated_by": "N/A",
            "verified_by": "N/A",
            "application_status": "PENDING",
            "notes": "N/A",
            "date_created": current_date,
            "date_updated": "N/A",
            "record_status": "ACTIVE"
        })

        application = mongo.db.applications.find_one({"_id": ObjectId(application_id)})
        application = json.loads(dumps(application))

        # currency = mongo.db.currencies.find_one({"_id": ObjectId(application["currency"])})
        # currency = json.loads(dumps(currency))
        # application["currency"] = currency

        return jsonify({
            "status": "success",
            "message": "You have successfully added {} application".format(application["product_name"]),
            "data": application,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })