import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

upload_applications_blueprint = Blueprint("upload_applications_blueprint", __name__)

@upload_applications_blueprint.route("/upload_applications", methods=["GET"])
def upload_applications():
    try:
        applications = mongo.db.applications.find()
        applications = json.loads(dumps(applications))
        print(applications)
        
        return jsonify({
            "status": "success",
            "message": "You have successfully uploaded all applications",
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })