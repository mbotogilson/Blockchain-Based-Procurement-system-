import json
from datetime import datetime

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

update_application_blueprint = Blueprint("update_application_blueprint", __name__)

@update_application_blueprint.route("/update_application", methods=["PUT"])
def update_application():
    request_data = request.json

    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d, %H:%M:%S")

    try:
        mongo.db.applications.update_one({
                "_id": ObjectId(request_data["application_id"]),
            },

            {"$set":{
                "product_name": request_data["product_name"],
                # "currency": request_data["currency"],
                "price": request_data["price"],
                "updated_by": request_data["updated_by"],
                "date_updated": current_date,
            }
        })

        application = mongo.db.applications.find_one({"_id": ObjectId(request_data["application_id"])})
        application = json.loads(dumps(application))
        
        # currency = mongo.db.currencies.find_one({"_id": ObjectId(application["currency"])})
        # currency = json.loads(dumps(currency))
        # application["currency"] = currency
        
        return jsonify({
            "status": "success",
            "message": "You have successfully updated {} application".format(application["product_name"]),
            "data": application,
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })