import json

from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

delete_application_blueprint = Blueprint("delete_application_blueprint", __name__)

@delete_application_blueprint.route("/delete_application/<application_id>", methods=["DELETE"])
def delete_application(application_id):
    # request_data = request.json
    # print(application_id)

    try:
        mongo.db.applications.update_one({
                "_id": ObjectId(application_id),
            },

            {"$set":{
                "record_status": "DELETED",
            }
        })

        application = mongo.db.applications.find_one({"_id": ObjectId(application_id)})
        application = json.loads(dumps(application))
        print(application)

        return jsonify({
            "status": "success",
            "message": "You have successfully deleted {} application".format(application["product_name"]),
            "data": application
        })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })