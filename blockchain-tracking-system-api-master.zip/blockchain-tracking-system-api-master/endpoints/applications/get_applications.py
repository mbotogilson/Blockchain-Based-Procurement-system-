import json

from flask import Blueprint, jsonify
from bson.objectid import ObjectId
from bson.json_util import dumps

from database.database import mongo

get_applications_blueprint = Blueprint("get_applications_blueprint", __name__)

@get_applications_blueprint.route("/get_applications", methods=["GET"])
def get_applications():
    try:
        # applications = mongo.db.applications.find({"record_status": {"$ne": "DELETED"}})
        applications = mongo.db.applications.find()
        applications = json.loads(dumps(applications))

        if len(applications) < 1:
            return jsonify({
                "status": "error",
                "message": "Sorry no applications found.",
            })

        else:
            # for application in applications:
            #     currency = mongo.db.currencies.find_one({"_id": ObjectId(application["currency"])})
            #     currency = json.loads(dumps(currency))
            #     application["currency"] = currency

            # print(applications)

            return jsonify({
                "status": "success",
                "message": "Applications were successfully retrieved.",
                "data": {
                    "applications": applications
                }
            })

    except:
        return jsonify({
            "status": "error",
            "message": "Sorry we are experiencing some technical incoveniences"
        })