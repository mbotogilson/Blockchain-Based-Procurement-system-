from flask import Flask
from flask_cors import CORS

from database.database import mongo

# BLUEPRINTS
# Auth
from endpoints.auth.signup import signup_blueprint
from endpoints.auth.login import login_blueprint

# Users
from endpoints.users.get_users import get_users_blueprint
from endpoints.users.update_user import update_user_blueprint
from endpoints.users.change_user_role import change_user_role_blueprint
from endpoints.users.delete_user import delete_user_blueprint

# Roles
from endpoints.roles.add_role import add_role_blueprint
from endpoints.roles.get_roles import get_roles_blueprint
from endpoints.roles.update_role import update_role_blueprint
from endpoints.roles.delete_role import delete_role_blueprint

# Currencies
from endpoints.currencies.add_currency import add_currency_blueprint
from endpoints.currencies.get_currencies import get_currencies_blueprint
from endpoints.currencies.update_currency import update_currency_blueprint
from endpoints.currencies.delete_currency import delete_currency_blueprint

# Applications
from endpoints.applications.add_application import add_application_blueprint
from endpoints.applications.get_applications import get_applications_blueprint
from endpoints.applications.verify_application import verify_application_blueprint
from endpoints.applications.update_application import update_application_blueprint
from endpoints.applications.delete_application import delete_application_blueprint
from endpoints.applications.upload_applications import upload_applications_blueprint

app = Flask(__name__)

CORS(app)

app.config["MONGO_URI"] = "mongodb://localhost:27017/procurement_system"
mongo.init_app(app)

# Blueprints Registration
# Auth
app.register_blueprint(signup_blueprint)
app.register_blueprint(login_blueprint)

# Users
app.register_blueprint(get_users_blueprint)
app.register_blueprint(update_user_blueprint)
app.register_blueprint(change_user_role_blueprint)
app.register_blueprint(delete_user_blueprint)

# Roles
app.register_blueprint(add_role_blueprint)
app.register_blueprint(get_roles_blueprint)
app.register_blueprint(update_role_blueprint)
app.register_blueprint(delete_role_blueprint)

# Currencies
app.register_blueprint(add_currency_blueprint)
app.register_blueprint(get_currencies_blueprint)
app.register_blueprint(update_currency_blueprint)
app.register_blueprint(delete_currency_blueprint)

# Applications
app.register_blueprint(add_application_blueprint)
app.register_blueprint(get_applications_blueprint)
app.register_blueprint(verify_application_blueprint)
app.register_blueprint(update_application_blueprint)
app.register_blueprint(delete_application_blueprint)
app.register_blueprint(upload_applications_blueprint)

if __name__ == "__main__":
    app.run(debug=True)